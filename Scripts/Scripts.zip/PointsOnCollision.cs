﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PointsOnCollision : MonoBehaviour {

    public GameObject manager;
    GameManager gm;

	// Use this for initialization
	void Start () {
        gm = manager.GetComponent<GameManager>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void OnCollisionEnter(Collision col)
    {
        Debug.Log("Hit");
        if(col.gameObject.tag == "Ball")
        {
            gm.StartCoroutine(gm.AddScore(100));
        }
    }
}
